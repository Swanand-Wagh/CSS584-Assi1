import _1 from './images/1.jpg';
import _2 from './images/2.jpg';
import _3 from './images/3.jpg';
import _4 from './images/4.jpg';
import _5 from './images/5.jpg';
import _6 from './images/6.jpg';
import _7 from './images/7.jpg';
import _8 from './images/8.jpg';
import _9 from './images/9.jpg';
import _10 from './images/10.jpg';
import _11 from './images/11.jpg';
import _12 from './images/12.jpg';
import _13 from './images/13.jpg';
import _14 from './images/14.jpg';
import _15 from './images/15.jpg';
import _16 from './images/16.jpg';
import _17 from './images/17.jpg';
import _18 from './images/18.jpg';
import _19 from './images/19.jpg';
import _20 from './images/20.jpg';
import _21 from './images/21.jpg';
import _22 from './images/22.jpg';
import _23 from './images/23.jpg';
import _24 from './images/24.jpg';
import _25 from './images/25.jpg';
import _26 from './images/26.jpg';
import _27 from './images/27.jpg';
import _28 from './images/28.jpg';
import _29 from './images/29.jpg';
import _30 from './images/30.jpg';
import _31 from './images/31.jpg';
import _32 from './images/32.jpg';
import _33 from './images/33.jpg';
import _34 from './images/34.jpg';
import _35 from './images/35.jpg';
import _36 from './images/36.jpg';
import _37 from './images/37.jpg';
import _38 from './images/38.jpg';
import _39 from './images/39.jpg';
import _40 from './images/40.jpg';
import _41 from './images/41.jpg';
import _42 from './images/42.jpg';
import _43 from './images/43.jpg';
import _44 from './images/44.jpg';
import _45 from './images/45.jpg';
import _46 from './images/46.jpg';
import _47 from './images/47.jpg';
import _48 from './images/48.jpg';
import _49 from './images/49.jpg';
import _50 from './images/50.jpg';
import _51 from './images/51.jpg';
import _52 from './images/52.jpg';
import _53 from './images/53.jpg';
import _54 from './images/54.jpg';
import _55 from './images/55.jpg';
import _56 from './images/56.jpg';
import _57 from './images/57.jpg';
import _58 from './images/58.jpg';
import _59 from './images/59.jpg';
import _60 from './images/60.jpg';
import _61 from './images/61.jpg';
import _62 from './images/62.jpg';
import _63 from './images/63.jpg';
import _64 from './images/64.jpg';
import _65 from './images/65.jpg';
import _66 from './images/66.jpg';
import _67 from './images/67.jpg';
import _68 from './images/68.jpg';
import _69 from './images/69.jpg';
import _70 from './images/70.jpg';
import _71 from './images/71.jpg';
import _72 from './images/72.jpg';
import _73 from './images/73.jpg';
import _74 from './images/74.jpg';
import _75 from './images/75.jpg';
import _76 from './images/76.jpg';
import _77 from './images/77.jpg';
import _78 from './images/78.jpg';
import _79 from './images/79.jpg';
import _80 from './images/80.jpg';
import _81 from './images/81.jpg';
import _82 from './images/82.jpg';
import _83 from './images/83.jpg';
import _84 from './images/84.jpg';
import _85 from './images/85.jpg';
import _86 from './images/86.jpg';
import _87 from './images/87.jpg';
import _88 from './images/88.jpg';
import _89 from './images/89.jpg';
import _90 from './images/90.jpg';
import _91 from './images/91.jpg';
import _92 from './images/92.jpg';
import _93 from './images/93.jpg';
import _94 from './images/94.jpg';
import _95 from './images/95.jpg';
import _96 from './images/96.jpg';
import _97 from './images/97.jpg';
import _98 from './images/98.jpg';
import _99 from './images/99.jpg';
import _100 from './images/100.jpg';

export const imageArray = [
  { id: 1, image: _1 },
  { id: 2, image: _2 },
  { id: 3, image: _3 },
  { id: 4, image: _4 },
  { id: 5, image: _5 },
  { id: 6, image: _6 },
  { id: 7, image: _7 },
  { id: 8, image: _8 },
  { id: 9, image: _9 },
  { id: 10, image: _10 },
  { id: 11, image: _11 },
  { id: 12, image: _12 },
  { id: 13, image: _13 },
  { id: 14, image: _14 },
  { id: 15, image: _15 },
  { id: 16, image: _16 },
  { id: 17, image: _17 },
  { id: 18, image: _18 },
  { id: 19, image: _19 },
  { id: 20, image: _20 },
  { id: 21, image: _21 },
  { id: 22, image: _22 },
  { id: 23, image: _23 },
  { id: 24, image: _24 },
  { id: 25, image: _25 },
  { id: 26, image: _26 },
  { id: 27, image: _27 },
  { id: 28, image: _28 },
  { id: 29, image: _29 },
  { id: 30, image: _30 },
  { id: 31, image: _31 },
  { id: 32, image: _32 },
  { id: 33, image: _33 },
  { id: 34, image: _34 },
  { id: 35, image: _35 },
  { id: 36, image: _36 },
  { id: 37, image: _37 },
  { id: 38, image: _38 },
  { id: 39, image: _39 },
  { id: 40, image: _40 },
  { id: 41, image: _41 },
  { id: 42, image: _42 },
  { id: 43, image: _43 },
  { id: 44, image: _44 },
  { id: 45, image: _45 },
  { id: 46, image: _46 },
  { id: 47, image: _47 },
  { id: 48, image: _48 },
  { id: 49, image: _49 },
  { id: 50, image: _50 },
  { id: 51, image: _51 },
  { id: 52, image: _52 },
  { id: 53, image: _53 },
  { id: 54, image: _54 },
  { id: 55, image: _55 },
  { id: 56, image: _56 },
  { id: 57, image: _57 },
  { id: 58, image: _58 },
  { id: 59, image: _59 },
  { id: 60, image: _60 },
  { id: 61, image: _61 },
  { id: 62, image: _62 },
  { id: 63, image: _63 },
  { id: 64, image: _64 },
  { id: 65, image: _65 },
  { id: 66, image: _66 },
  { id: 67, image: _67 },
  { id: 68, image: _68 },
  { id: 69, image: _69 },
  { id: 70, image: _70 },
  { id: 71, image: _71 },
  { id: 72, image: _72 },
  { id: 73, image: _73 },
  { id: 74, image: _74 },
  { id: 75, image: _75 },
  { id: 76, image: _76 },
  { id: 77, image: _77 },
  { id: 78, image: _78 },
  { id: 79, image: _79 },
  { id: 80, image: _80 },
  { id: 81, image: _81 },
  { id: 82, image: _82 },
  { id: 83, image: _83 },
  { id: 84, image: _84 },
  { id: 85, image: _85 },
  { id: 86, image: _86 },
  { id: 87, image: _87 },
  { id: 88, image: _88 },
  { id: 89, image: _89 },
  { id: 90, image: _90 },
  { id: 91, image: _91 },
  { id: 92, image: _92 },
  { id: 93, image: _93 },
  { id: 94, image: _94 },
  { id: 95, image: _95 },
  { id: 96, image: _96 },
  { id: 97, image: _97 },
  { id: 98, image: _98 },
  { id: 99, image: _99 },
  { id: 100, image: _100 },
];
